package dao;

import static db.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dto.MemberDTO;

public class MemberDAO {
		private static MemberDAO dao;
		Connection con;
		PreparedStatement pstmt;
		ResultSet rs;
		
		public MemberDAO() {
			
		}
		
		public static MemberDAO getInstance() {
			if (dao == null) {
				dao = new MemberDAO();
			}
			return dao;
		}

		public void setConnection(Connection con) {
			this.con = con;
		}

		public boolean idCheck(String id) {

			boolean result = false;
			String sql = "SELECT COUNT(*) FROM JSY_MEMBER WHERE STUID=?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, id);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					result= rs.getInt(1)==1?true:false;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				close(pstmt);
				close(rs);
			}
			return result;
		}

		public boolean memberJoin(MemberDTO member) {
			boolean result = false;
			System.out.println("dao왓따");
			String sql = "INSERT INTO JSY_MEMBER VALUES(?,?,NULL,?,?,NULL)";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, member.getUserId());
				pstmt.setString(2, member.getUserPw());
				pstmt.setString(3, member.getUserName());
				pstmt.setString(4, member.getUserEmail());

				result = (pstmt.executeUpdate()==1)?true:false;
				
				System.out.println("dao result : "+result);
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close(pstmt);
			}
			return result;
		}
		
}