package service;

import static db.JdbcUtil.close;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;

import dao.MemberDAO;
import static dao.MemberDAO.*;

public class CheckIdService {

	public boolean idcheck(String id) {
		// TODO Auto-generated method stub
		MemberDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		
		boolean result = dao.idCheck(id);
		close(con);
		
		return result;
	}

}
