package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.MemberDTO;
import service.MemberService;

/**
 * Servlet implementation class joinMember
 */
@WebServlet("/joinController")
public class joinController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public joinController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		System.out.println("controller 왔따");
		// dto와 service import
		MemberDTO member = new MemberDTO();
		MemberService joinsvc = new MemberService();
	
		// jsp에서 넘어온 정보를
		// dto 타입인 member에 저장
		member.setUserId(request.getParameter("stuId"));
		member.setUserPw(request.getParameter("checkPw"));
		member.setUserName(request.getParameter("stuName"));
		member.setUserEmail(request.getParameter("stuEmail"));
		
		if(joinsvc.memberJoin(member)) {
			response.sendRedirect("login.html");
		} else {
			response.sendRedirect("register.jsp");
		}	
	}

}
